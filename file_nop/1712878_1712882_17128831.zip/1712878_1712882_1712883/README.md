* Nhóm em tên là : NoName
* Số thự tự trong đăng ký: 26
* Vì chưa có danh sách nhóm chính thức từ thầy nên tên folder tụi em nộp là MSSV các thành viên